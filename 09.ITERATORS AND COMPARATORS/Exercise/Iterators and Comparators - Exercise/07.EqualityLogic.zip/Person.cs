﻿namespace _07.EqualityLogic
{
    using System;
    public class Person : IComparable<Person>
    {
        public Person(string name, int age)
        {
            this.Name = name;
            this.Age = age;
        }

        public string Name { get; set; }

        public int Age { get; set; }

        public int CompareTo(Person other)
        {
            var resultOfCompare = this.Name.CompareTo(other.Name);

            if (resultOfCompare == 0)
            {
                return this.Age.CompareTo(other.Age);
            }

            return resultOfCompare;
        }

        public override bool Equals(object obj)
        {
            if (obj is Person person)
            {
                return this.Name == person.Name && this.Age == person.Age;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return this.Name.GetHashCode() + this.Age.GetHashCode();
        }
    }
}
